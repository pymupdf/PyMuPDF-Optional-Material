============
Classes
============

.. toctree::
   :maxdepth: 2

   annot.rst
   colorspace.rst
   displaylist.rst
   document.rst
   font.rst
   identity.rst
   irect.rst
   link.rst
   linkdest.rst
   matrix.rst
   outline.rst
   page.rst
   pixmap.rst
   point.rst
   quad.rst
   rect.rst
   shape.rst
   textpage.rst
   textwriter.rst
   tools.rst
   widget.rst
