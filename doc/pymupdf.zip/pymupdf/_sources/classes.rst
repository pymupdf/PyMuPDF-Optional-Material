============
Classes
============

.. toctree::
   :maxdepth: 2

   annot
   colorspace
   displaylist
   document
   font
   identity
   irect
   link
   linkdest
   matrix
   outline
   page
   pixmap
   point
   quad
   rect
   shape
   textpage
   textwriter
   tools
   widget
