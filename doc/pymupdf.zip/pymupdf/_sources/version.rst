Covered Version
--------------------

This documentation covers PyMuPDF v1.18.9 features as of **2021-02-26 13:46:32**.

.. note:: The major and minor versions of **PyMuPDF** and **MuPDF** will always be the same. Only the third qualifier (patch level) may deviate from that of MuPDF.