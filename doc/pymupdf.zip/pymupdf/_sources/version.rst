Covered Version
--------------------

This documentation covers PyMuPDF v1.18.10 features as of **2021-03-22 05:51:27**.

.. note:: The major and minor versions of **PyMuPDF** and **MuPDF** will always be the same. Only the third qualifier (patch level) may deviate from that of MuPDF.