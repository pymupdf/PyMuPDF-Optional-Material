Covered Version
--------------------

This documentation covers PyMuPDF v1.18.14 features as of **2021-06-01 08:11:38**.

.. note:: The major and minor versions of **PyMuPDF** and **MuPDF** will always be the same. Only the third qualifier (patch level) may deviate from that of MuPDF.