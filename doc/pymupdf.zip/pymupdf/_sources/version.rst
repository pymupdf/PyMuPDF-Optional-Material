Covered Version
--------------------

This documentation covers PyMuPDF v1.18.13 features as of **2021-04-29 09:59:29**.

.. note:: The major and minor versions of **PyMuPDF** and **MuPDF** will always be the same. Only the third qualifier (patch level) may deviate from that of MuPDF.