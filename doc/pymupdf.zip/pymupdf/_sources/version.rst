Covered Version
--------------------

This documentation covers PyMuPDF v1.19.1 features as of **2021-10-23 00:00:01**.

.. note:: The major and minor versions of **PyMuPDF** and **MuPDF** will always be the same. Only the third qualifier (patch level) may deviate from that of MuPDF.