Covered Version
--------------------

This documentation covers PyMuPDF v1.18.13 features as of **2021-05-05 06:32:22**.

.. note:: The major and minor versions of **PyMuPDF** and **MuPDF** will always be the same. Only the third qualifier (patch level) may deviate from that of MuPDF.