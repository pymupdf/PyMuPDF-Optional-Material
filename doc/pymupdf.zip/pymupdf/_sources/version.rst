Covered Version
--------------------

This documentation covers PyMuPDF v1.18.19 features as of **2021-09-16 16:45:29**.

.. note:: The major and minor versions of **PyMuPDF** and **MuPDF** will always be the same. Only the third qualifier (patch level) may deviate from that of MuPDF.