**PyMuPDF Documentation**
=================================

.. toctree::
   :maxdepth: 4

   intro.rst
   installation.rst
   tutorial.rst
   faq.rst
   module.rst
   classes.rst
   algebra.rst
   lowlevel.rst
   glossary.rst
   vars.rst
   colors.rst
   app1.rst
   app2.rst
   app3.rst
   app4.rst
   changes.rst
   znames.rst
