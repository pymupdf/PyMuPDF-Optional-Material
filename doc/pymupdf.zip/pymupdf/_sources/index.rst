**PyMuPDF Documentation**
=================================

.. toctree::
   :maxdepth: 4

   intro
   installation
   tutorial
   faq
   module
   classes
   algebra
   lowlevel
   glossary
   vars
   colors
   app1
   app2
   app3
   app4
   changes
   znames
